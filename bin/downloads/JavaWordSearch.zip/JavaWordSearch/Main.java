import ch08.trees.*;
import java.io.*;
import java.util.Scanner;
import java.util.ArrayList;

public class Main
{
    public static String recRemovePunc(String word)
    {
	int length = word.length();
	char front = word.charAt(0);
	char end = word.charAt(length-1);
	if((front == '"')||(end == '$')||(end == '(')||(front == '[')) {
	    return recRemovePunc(word.substring(1)); }
	if((end == '"')||(end == ',')||(end == '.')||(end == '?')||(end == '!')||(end == ';')||(end == ')')||(end == ']')) {
	    return recRemovePunc(word.substring(0 , (length-1))); }
	else return word;
	
    }
    public static String printTreeContents(BinarySearchTree tree)
    {
	String set = "";
	tree.reset(1);
	System.out.println("Tree Size:  " + tree.size());
	for(int i = 0 ; i < tree.size() ; i++) {
	    Word atWord = (Word)tree.getNext(1);
	    set += atWord + "\n\n";}
	return set;
    }
    public static void main(String[]args)
    {
	BinarySearchTree tree = new BinarySearchTree();
	ArrayList<String> lines = new ArrayList<String>();
	
	try {
	    File fin = new File("PeterRabbit.txt");
	    Scanner rawTxt = new Scanner(fin);
	    
	    while(rawTxt.hasNextLine()) {     //Create ArrayList of lines
		String curLine = rawTxt.nextLine();
		lines.add(curLine); }
	    
	    for(int i = 0 ; i < lines.size() ; i++) {    //By word in line
		String line = lines.get(i);
		Scanner scan = new Scanner(line);
		while(scan.hasNext()) {
		    String Winfo = scan.next();
		    Winfo = recRemovePunc(Winfo);   //Remove non-AlphaChars
		    Word curWord = new Word(Winfo);
		    boolean isIn = tree.contains(curWord);
		    if(isIn == false) {     //Adds new Word
			tree.add(curWord);
			((Word)tree.get(curWord)).hit(i+1); }
		    else ((Word)tree.get(curWord)).hit(i+1);    //Adds hit to existing
		}
	    }
	    System.out.println(printTreeContents(tree));
	}
	catch(IOException ex) {
	    System.out.println (ex.toString());
    	    System.out.println("Could not find file"); }   
    }
}