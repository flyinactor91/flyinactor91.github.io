import java.util.ArrayList;

public class Word implements Comparable<Word>
{
    protected String info;
    protected int count;
    protected ArrayList<Integer> lines = new ArrayList<Integer>();
    
    public Word(String w)
    {
	info = w.toLowerCase();
	count = 0;
    }
    public void hit(int line)
    {
	count++;
	lines.add(line);
    }
    public String getInfo()
    {
	return info;
    }
    public int getCount()
    {
	return count;
    }
    public boolean equals(Word wComp)
    {
	if(info == wComp.info) return true;
	return false;
    }
    public int compareTo(Word wComp)
    {
	int i = (info.toUpperCase()).compareTo(wComp.info.toUpperCase());
	return i;
    }
    public String toString()
    {
	String set = info + ":  " + count + " occurrences";
	for(int i = 0 ; i < lines.size() ; i++) {
	    if(i%10 == 0) set += "\n\t";
	    set += lines.get(i) + " "; }
	return set;
    }
}