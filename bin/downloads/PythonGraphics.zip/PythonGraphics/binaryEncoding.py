##Author: michael.dupont@centre.edu
##Assignment: Program 4
##Associated files: None
##
##Authorship & Assistance:
##      -I wrote this code with no assistance other than that listed here
##	        -None
##      -I provided assistance to the following:
##		-Casey Faist
##
##Self Assessment:
##		-Well...this was certainly the fastest of the four programs we've made.
##               I'm not sure if it was because it was less time intensive or that the
##               functional elements of the program had already been written. A few
##               problems connecting strings and lists but pretty straightforward.
##               Follows the program description while also separating the various
##               components into individual programs. I changed a few things to the
##               original code like adding the inButton function at the end to close the
##               window only when the button was clicked. It adds continuity to the
##               function of the go button and there was nothing expressly forbidding it.
##               They were mostly moving the entry points to be equidistant to the colons.
##               I also added a user input error function to check if all of the entries
##               were in the right format and give instructions on how to fix them.
##
##Time:
##		-Three hours at the computer and none away. One was spent only working
##               the user error function.
##
##Reflection:
##		-It would be fun to add this to the contact list program.

    
from graphics import *
def b2d(Bin):
	Dec = 0
	exp = len(Bin) - 1
	for digit in Bin:
		val = int(digit)*2**exp
		Dec = Dec + val
		exp = exp - 1
	return Dec
def d2b(dec , L):
	Bin = list()
	for i in range(L):
		R = dec % 2
		dec = dec / 2
		Bin.insert(0 , R)
	return Bin
def DataCheck( Sex , Date , EyeC , Height ):
        V = True 
        if Sex.upper().strip() == "M":
                V = True
        elif Sex.upper().strip() == "F":
                V = True
        else:
                V = False
                print "Sex should be either 'M' or 'F'"
        if Date[:2].isdigit() == False or Date[3:5].isdigit() == False or Date[6:].isdigit() == False:
                V = False
                print "Date should follow mm/dd/yyyy format. Month and day should have two digits each and year should have four"
        EC = EyeC.upper().strip()
        if EC == "BRN":
                V = True
        elif EC == "BLU":
                V = True
        elif EC == "HAZ":
                V = True
        elif EC == "GRN":
                V = True
        elif EC == "GRY":
                V = True
        elif EC == "OTHER":
                V = True
        else:
                V = False
                print "Eye Color should be entered as 'brn', 'blu', 'haz', 'grn', 'gry', or 'other'"
        if Height.isdigit() == False:
                V = False
                print "Height in inches should be a number between 0 and 127"
        return V
def Sex2bin( Sex ):
	if Sex.upper().strip() == "M":
		return [1]
	if Sex.upper().strip() == "F":
		return [0]
def DOB2bin( Date ):
        Datebin = list()
        M = d2b(int(Date[:2]) , 4)
        D = d2b(int(Date[3:5]) , 5)
        Y = d2b(int(Date[6:]) - 1900 , 9)
        for digit in Y:
                Datebin.append(digit)
        for digit in M:
                Datebin.append(digit)
        for digit in D:
                Datebin.append(digit)
        return Datebin
def Eye2bin( EyeC ):
	if EyeC.upper().strip() == "BRN":
		return [0,0,0]
	if EyeC.upper().strip() == "BLU":
		return [0,0,1]
	if EyeC.upper().strip() == "HAZ":
		return [0,1,0]
	if EyeC.upper().strip() == "GRN":
		return [0,1,1]
	if EyeC.upper().strip() == "GRY":
		return [1,0,0]
	if EyeC.upper().strip() == "OTHER":
		return [1,0,1]
def Height2bin( Height ): return d2b(int(Height) , 7)
def encoding(Sex , DOB , EyeColor , Height):
        RetBin = [0,0,0]
        S = Sex2bin(Sex)
        for digit in S:
                RetBin.append(digit)
        D = DOB2bin(DOB)
        for digit in D:
                RetBin.append(digit)
        E = Eye2bin(EyeColor)
        for digit in E:
                RetBin.append(digit)
        H = Height2bin(Height)
        for digit in H:
                RetBin.append(digit)
        return b2d(RetBin)
def bin2Sex( Bin ):
	if Bin[3] == 1:
		return "M"
	if Bin[3] == 0:
		return "F"
def bin2DOB( Bin ):
        Y = b2d(Bin[4:13]) + 1900
        M = b2d(Bin[13:17])
        D = b2d(Bin[17:22])
        return str(M)+"/"+str(D)+"/"+str(Y)
def bin2Eye( Bin ):
	if Bin[22:25] == [0,0,0]:
		return "brn"
	if Bin[22:25] == [0,0,1]:
		return "blu"
	if Bin[22:25] == [0,1,0]:
		return "haz"
	if Bin[22:25] == [0,1,1]:
		return "grn"
	if Bin[22:25] == [1,0,0]:
		return "gry"
	if Bin[22:25] == [1,0,1]:
		return "other"
def bin2Height( Bin ): return b2d(Bin[25:])
def decoding(rawCode):
        Bin = d2b(int(rawCode) , 32)
        S = bin2Sex(Bin)
        D = bin2DOB(Bin)
        E = bin2Eye(Bin)
        H = bin2Height(Bin)
        RetL = list()
        RetL.append(S)
        RetL.append(D)
        RetL.append(E)
        RetL.append(H)
        return RetL
def inButton( click, button ):
        p1 = button.getP1()
        p2 = button.getP2()
        return p1.getX() <= click.getX() <= p2.getX() and p2.getY() <= click.getY() <= p1.getY() 
def main():
        win = GraphWin( "Data Panel", 300, 400 )
        win.setCoords( 0,0,60,7 )
        sLabel = Text( Point( 6, 6.0 ), "Sex: " )
        sLabel.draw(win)
        sEntry = Entry( Point( 14, 6.0 ), len(" M/F ") )
        sEntry.setText("M/F")
        sEntry.draw(win)
        dLabel = Text( Point( 6, 5.0 ), "DOB: ")
        dLabel.draw(win)
        dEntry = Entry( Point( 21, 5.0 ), len(" mm/dd/yyyy ") )
        dEntry.setText( "mm/dd/yyyy" )
        dEntry.draw(win)
        eLabel = Text( Point( 6, 4.0 ), "Eyes: " )
        eLabel.draw(win)
        eEntry = Entry( Point( 33, 4.0 ), len("brn,blu,haz,grn,gry,other") )
        eEntry.setText("brn,blu,haz,grn,gry,other")
        eEntry.draw(win)
        hLabel = Text( Point( 6, 3.0 ), "Ht: " )
        hLabel.draw(win)
        hEntry = Entry( Point( 14, 3.0 ), len( "inches") )
        hEntry.setText( "inches" )
        hEntry.draw(win)
        cLabel = Text ( Point( 6, 1.75 ), "Code: " )
        cLabel.draw(win)
        cEntry = Entry( Point( 19, 1.75), len(str("444444444")))
        cEntry.draw(win)
        button = Rectangle( Point( 40, 1.25 ), Point( 50, 0.75 ) )
        button.draw(win)
        bLabel = Text( button.getCenter(), "go" )
        bLabel.draw(win)
        EMess = Text( Point( 43, 2.75 ), "" )
        EMess.draw(win)
        click = win.getMouse()
        while not inButton( click, button ):
                click = win.getMouse()
        rawSex = sEntry.getText()
        rawDOB = dEntry.getText()
        rawEyeColor = eEntry.getText()
        rawHeight = hEntry.getText()
        rawCode = cEntry.getText()
        if rawCode.isdigit() == 1:
                L = decoding(rawCode)
                sEntry.setText(L[0])
                dEntry.setText(L[1])
                eEntry.setText(L[2])
                hEntry.setText(L[3])
        else:
                DC = DataCheck(rawSex , rawDOB , rawEyeColor , rawHeight)
                Iter = 0
                while DC is not True:
                        Iter = Iter + 1
                        print "Incorrect Data" , Iter
                        print ""
                        EMess.setText("Incorrect Data \n \n See shell for details")
                        click = win.getMouse()
                        while not inButton( click, button ):
                                click = win.getMouse()
                        rawSex = sEntry.getText()
                        rawDOB = dEntry.getText()
                        rawEyeColor = eEntry.getText()
                        rawHeight = hEntry.getText()
                        DC = DataCheck(rawSex , rawDOB , rawEyeColor , rawHeight)
                EMess.undraw()
                h = encoding(rawSex , rawDOB , rawEyeColor , rawHeight)
                cEntry.setText(h)
                if Iter == 1:
                        print "It only took 1 try"
                if Iter > 1:
                        print "It only took" , Iter , "tries"
        bLabel.setText("close")
        click = win.getMouse()
        while not inButton( click, button ):
                click = win.getMouse()
        win.close()
main()
