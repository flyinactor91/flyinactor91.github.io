from graphics import *
from math import *

#This sets up the basic graph

win = GraphWin("Mandelbrot Color Graph", 600 , 600)
win.setCoords(-2 , -2 , 2 , 2)

#Below are the z points to insert to make the Mandelbrot set

for numx in range(0 , 600, 1):
    x = -2 + ( numx / 599.0 ) * 4
    for numy in range(0 , 600, 1):
        y = -2 + ( numy / 599.0 ) * 4
        a = x
        b = y
        t = 0
        d = 0
        u = sqrt( x**2 + y**2 )
        while u <= 2 :
            while t <= 1000 and d <= 2 :
                a1 = a**2 - b**2 + x
                b1 = 2 * a * b + y
                a = a1
                b = b1
                t = t + 1
                d = sqrt( a**2 + b**2 )
            if d <= 2 and t >= 1000 :
                z = Point( x , y )
                z.draw(win)
                break
            else :
                z = Point ( x, y )
                z.setFill(color_rgb(int(255-(t%4)/4.0*255),int((t%4)/4.0*255),0))
                z.draw(win)
                break
win.getMouse() #pause for click in window
win.close()
