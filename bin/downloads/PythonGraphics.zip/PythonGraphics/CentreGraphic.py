from graphics import *

def main():
    #Win
    win = GraphWin('CentreGraphic' , 600 , 600)
    win.setCoords(-5 , -5 , 5 , 5)
    win.setBackground('black')
    #top
    top = Polygon(Point(-4.875 , 2) , Point(0 , 3.2) , Point(4.875 , 2))
    top.setFill('white')
    top.setOutline('white')
    top.draw(win)
    #top bar
    tbar = Polygon(Point(-4.65 , 1.61) , Point(4.65 , 1.61) , Point(4.65 , 1.12) , Point(-4.65 , 1.12))
    tbar.setFill('white')
    tbar.setOutline('white')
    tbar.draw(win)
    #top bar ext
    tbarx = Polygon(Point(-4.7375 , 1.61) , Point(4.7375 , 1.61) , Point(4.7375 , 1.335) , Point(-4.7375 , 1.335))
    tbarx.setFill('white')
    tbarx.setOutline('white')
    tbarx.draw(win)
    #top left round
    tlr = Circle(Point(-4.7375 , 1.4725) , .1375)
    tlr.setFill('white')
    tlr.setOutline('white')
    tlr.draw(win)
    #top right round
    trr = Circle(Point(4.7375 , 1.4725) , .1375)
    trr.setFill('white')
    trr.setOutline('white')
    trr.draw(win)
    #tcol1
    tcol1 = Polygon(Point(-4.65 , 1) , Point(-3.9 , 1) , Point(-4 , .85) , Point(-4.55 , .85))
    tcol1.setFill('white')
    tcol1.setOutline('white')
    tcol1.draw(win)
    #tcol2
    tcol2 = Polygon(Point(-3.1 , 1) , Point(-2.35 , 1) , Point(-2.45 , .85) , Point(-3 , .85))
    tcol2.setFill('white')
    tcol2.setOutline('white')
    tcol2.draw(win)
    #tcol3
    tcol3 = Polygon(Point(-1.55 , 1) , Point(-.8 , 1) , Point(-.9 , .85) , Point(-1.45 , .85))
    tcol3.setFill('white')
    tcol3.setOutline('white')
    tcol3.draw(win)
    #tcol4
    tcol4 = Polygon(Point(1.55 , 1) , Point(.8 , 1) , Point(.9 , .85) , Point(1.45 , .85))
    tcol4.setFill('white')
    tcol4.setOutline('white')
    tcol4.draw(win)
    #tcol5
    tcol5 = Polygon(Point(3.1 , 1) , Point(2.35 , 1) , Point(2.45 , .85) , Point(3 , .85))
    tcol5.setFill('white')
    tcol5.setOutline('white')
    tcol5.draw(win)
    #tcol6
    tcol6 = Polygon(Point(4.65 , 1) , Point(3.9 , 1) , Point(4 , .85) , Point(4.55 , .85))
    tcol6.setFill('white')
    tcol6.setOutline('white')
    tcol6.draw(win)
    #col1
    col1 = Polygon(Point(-4.55 , .73) , Point(-4 , .73) , Point(-4 , -2.22) , Point(-4.55 , -2.22))
    col1.setFill('white')
    col1.setOutline('white')
    col1.draw(win)
    #col2
    col2 = Polygon(Point(-3 , .73) , Point(-2.45 , .73) , Point(-2.45 , -2.22) , Point(-3 , -2.22))
    col2.setFill('white')
    col2.setOutline('white')
    col2.draw(win)
    #col3
    col3 = Polygon(Point(-1.45 , .73) , Point(-.9 , .73) , Point(-.9 , -2.22) , Point(-1.45 , -2.22))
    col3.setFill('white')
    col3.setOutline('white')
    col3.draw(win)
    #col4
    col4 = Polygon(Point(1.45 , .73) , Point(.9 , .73) , Point(.9 , -2.22) , Point(1.45 , -2.22))
    col4.setFill('white')
    col4.setOutline('white')
    col4.draw(win)
    #col5
    col5 = Polygon(Point(3 , .73) , Point(2.45 , .73) , Point(2.45 , -2.22) , Point(3 , -2.22))
    col5.setFill('white')
    col5.setOutline('white')
    col5.draw(win)
    #col6
    col6 = Polygon(Point(4.55 , .73) , Point(4 , .73) , Point(4 , -2.22) , Point(4.55 , -2.22))
    col6.setFill('white')
    col6.setOutline('white')
    col6.draw(win)
    #bcol1
    bcol1 = Polygon(Point(-4.65 , -2.49) , Point(-3.9 , -2.49) , Point(-4 , -2.34) , Point(-4.55 , -2.34))
    bcol1.setFill('white')
    bcol1.setOutline('white')
    bcol1.draw(win)
    #bcol2
    bcol2 = Polygon(Point(-3.1 , -2.49) , Point(-2.35 , -2.49) , Point(-2.45 , -2.34) , Point(-3 , -2.34))
    bcol2.setFill('white')
    bcol2.setOutline('white')
    bcol2.draw(win)
    #bcol3
    bcol3 = Polygon(Point(-1.55 , -2.49) , Point(-.8 , -2.49) , Point(-.9 , -2.34) , Point(-1.45 , -2.34))
    bcol3.setFill('white')
    bcol3.setOutline('white')
    bcol3.draw(win)
    #bcol4
    bcol4 = Polygon(Point(1.55 , -2.49) , Point(.8 , -2.49) , Point(.9 , -2.34) , Point(1.45 , -2.34))
    bcol4.setFill('white')
    bcol4.setOutline('white')
    bcol4.draw(win)
    #bcol5
    bcol5 = Polygon(Point(3.1 , -2.49) , Point(2.35 , -2.49) , Point(2.45 , -2.34) , Point(3 , -2.34))
    bcol5.setFill('white')
    bcol5.setOutline('white')
    bcol5.draw(win)
    #bcol6
    bcol6 = Polygon(Point(4.65 , -2.49) , Point(3.9 , -2.49) , Point(4 , -2.34) , Point(4.55 , -2.34))
    bcol6.setFill('white')
    bcol6.setOutline('white')
    bcol6.draw(win)
    #bottom bar 1
    bbar1 = Polygon(Point(-4.75 , -2.61) , Point(-.70 , -2.61) , Point(-.70 , -3.1) , Point(-4.75 , -3.1))
    bbar1.setFill('white')
    bbar1.setOutline('white')
    bbar1.draw(win)
    #bottom bar 2
    bbar2 = Polygon(Point(4.75 , -2.61) , Point(.70 , -2.61) , Point(.70 , -3.1) , Point(4.75 , -3.1))
    bbar2.setFill('white')
    bbar2.setOutline('white')
    bbar2.draw(win)
    #top step
    tstep = Polygon(Point(-.58 , -2.67) , Point(.58 , -2.67) , Point(.58 , -2.78) , Point(-.58 , -2.78))
    tstep.setFill('white')
    tstep.setOutline('white')
    tstep.draw(win)
    #middle step
    mstep = Polygon(Point(-.58 , -2.89) , Point(.58 , -2.89) , Point(.58 , -3) , Point(-.58 , -3))
    mstep.setFill('white')
    mstep.setOutline('white')
    mstep.draw(win)
    #bottom step
    bstep = Polygon(Point(-.58 , -3.11) , Point(.58 , -3.11) , Point(.58 , -3.22) , Point(-.58 , -3.22))
    bstep.setFill('white')
    bstep.setOutline('white')
    bstep.draw(win)
    #light
    lt = Polygon(Point(-.1 , .3) , Point(.1 , .3) , Point(.21 , 0) , Point(.1 , -.3) , Point(-.1 , -.3) , Point(-.21 , 0))
    lt.setFill('white')
    lt.setOutline('white')
    lt.draw(win)
    #semicircle left
    smcr = Circle(Point(-.09 , -1.15) , .4)
    smcr.setFill('white')
    smcr.setOutline('white')
    smcr.draw(win)
    #semicircle right
    smcr = Circle(Point(.09 , -1.15) , .4)
    smcr.setFill('white')
    smcr.setOutline('white')
    smcr.draw(win)
    #semicirlce mid fill
    smcrf = Polygon(Point(-.09 , -.75) , Point(.09 , -.75) , Point(.09 , -1.15) , Point(-.09 , -1.15))
    smcrf.setFill('white')
    smcrf.setOutline('white')
    smcrf.draw(win)
    #Semiblack fill
    nsmcr = Polygon(Point(-.49 , -1.15) , Point(.49 , -1.15) , Point(.49 , -1.55) , Point(-.49 , -1.55))
    nsmcr.setFill('black')
    nsmcr.draw(win)
    #left out door
    lodr = Polygon(Point(-.54 , -2.5) , Point(-.3525 , -2.5) , Point(-.3525 , -1.27) , Point(-.54 , -1.27))
    lodr.setFill('white')
    lodr.setOutline('white')
    lodr.draw(win)
    #left mid door
    lmdr = Polygon(Point(-.2425 , -2.5) , Point(-.0775 , -2.5) , Point(-.0775 , -1.64) , Point(-.2425 , -1.64))
    lmdr.setFill('white')
    lmdr.setOutline('white')
    lmdr.draw(win)
    #right mid door
    lmdr = Polygon(Point(.2425 , -2.5) , Point(.0775 , -2.5) , Point(.0775 , -1.64) , Point(.2425 , -1.64))
    lmdr.setFill('white')
    lmdr.setOutline('white')
    lmdr.draw(win)
    #right out door
    rodr = Polygon(Point(.54 , -2.5) , Point(.3525 , -2.5) , Point(.3525 , -1.27) , Point(.54 , -1.27))
    rodr.setFill('white')
    rodr.setOutline('white')
    rodr.draw(win)
    #right mid door
    lmdr = Polygon(Point(-.2425 , -1.48) , Point(.2425 , -1.48) , Point(.2425 , -1.27) , Point(-.2425 , -1.27))
    lmdr.setFill('white')
    lmdr.setOutline('white')
    lmdr.draw(win)
    #
    win.getMouse()
    win.close()
    

main()
