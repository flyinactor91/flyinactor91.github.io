from graphics import*

#This sets up the basic graph with the axis

win = GraphWin("PlotGraph", 1000 , 600)
win.setCoords(2.4 , -0.05 , 4.2 , 1)
point1=Point(2.4,0)
point2=Point(4.2,0)
point3=Point(2.45,-0.05)
point4=Point(2.45,1)
Line(point1,point2).draw(win)
Line(point3,point4).draw(win)
#win2 = GraphWin("DiffEquBiferGraph", 500 , 350)
#win2.setCoords(-.1 , -0.1 , 5.5 , 2.5)

#Below is the logistic function to insert

a=2.45
i=1
x=.5
while a <= 5 : 
    while i <= 500 :
        y = a * x * ( 1 - x )
        x = y
        i = i + 1
    while 499 <= i <= 520 :
        y = a * x * ( 1 - x )
        Point( a , x ).draw(win)
        #print x
        x = y
        i = i + 1
    a = a + .001
    x = 0.5
    i = 1

win.getMouse()
win.close()
