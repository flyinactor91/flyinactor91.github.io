from graphics import *
import math
import time
def sgv1():
    win = GraphWin( "Gallery", 320, 80 )
    radius = 20
    dx = 4
    dt = 0.1
    for k in range(10):
        cir = Circle( Point(-10, 50 ), radius )
        cir.draw(win)
        done = False
        while not done:
            cir.move( dx,0)
            time.sleep(dt)
            clk = win.checkMouse()
            if clk:
                cird = cir.getCenter()
                dist = math.sqrt( (cird.getX() - clk.getX())**2 + (cird.getY()-clk.getY())**2)
                if dist < radius:
                    cir.undraw()
                    cir = Circle(Point(cird.getX() , cird.getY()) , radius)
                    cir.setFill('red')
                    cir.setOutline('orange')
                    cir.draw(win)
                    time.sleep(.05)
                    cir.undraw()
                    done = True
            if not done:
                done = cir.getCenter().getX() > 300
        radius -= 2
        dt = dt - 0.01
    win.getMouse()
    time.sleep(2)
    win.close()
sgv1()
