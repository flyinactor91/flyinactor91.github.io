import turtle
turtle.speed(0)
set = "F"
for i in range(5):
    set = set.replace("F","FLFRFLF")
set = set + "R" + set + "R" + set
turtle.down()
for move in set:
    if move is "F": turtle.forward(100.0/3**i)
    if move is "L": turtle.left(60)
    if move is "R": turtle. right(120)
