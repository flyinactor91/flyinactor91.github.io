from graphics import*
from math import *

##############

win = GraphWin("PlanetOrbitGraphModded", 600 , 600)
win.setCoords( -3 * 10**11 , -3 * 10**11 , 3 * 10**11 , 3 * 10**11 )
point1=Point( -3 * 10**11 , 0 )
point2=Point( 3 * 10**11 , 0 )
point3=Point( 0 , -3 * 10**11 )
point4=Point( 0 , 3 * 10**11 )
Point( 10**11 , 0 ).draw(win)
Point( -10**11 , 0 ).draw(win)
#Line(point1,point2).draw(win)
#Line(point3,point4).draw(win)

##############

m1 = 2.0 * 10**30    #Sun 1
m2 = 2.0 * 10**30    #Sun 2
m3 = 6.0 * 10**24    #Earth
t = 0.0
dt = 2000
x1 = 10.0**11
y1 = 0.0
x2 = -10.0**11
y2 = 0.0
x3 = 1.5 * 10**11
y3 = 0.0
x4 = 1.502 * 10**11
y4 = 0.0
vx1 = 0.0
vy1 = 57000.0
vx2 = 0.0
vy2 = 57000.0
G = 6.674 * 10**-11
r1a = sqrt( ( x1 - x3 )**2 + ( y1 - y3 )**2 )
r2a = sqrt( ( x2 - x3 )**2 + ( y2 - y3 )**2 )
r1b = sqrt( ( x1 - x3 )**2 + ( y1 - y3 )**2 )
r2b = sqrt( ( x2 - x3 )**2 + ( y2 - y3 )**2 )
while t <= 10*50 :
    r1a = sqrt( ( x1 - x3 )**2 + ( y1 - y3 )**2 )
    r2a = sqrt( ( x2 - x3 )**2 + ( y2 - y3 )**2 )
    r1b = sqrt( ( x1 - x4 )**2 + ( y1 - y4 )**2 )
    r2b = sqrt( ( x2 - x4 )**2 + ( y2 - y4 )**2 )
    Fx1a = ( ( G * m1 * m3 ) / r1a**3 ) * -( x3 - x1 )
    Fy1a = ( ( G * m1 * m3 ) / r1a**3 ) * -( y3 + y1 )
    Fx2a = ( ( G * m2 * m3 ) / r2a**3 ) * -( x3 - x2 )
    Fy2a = ( ( G * m2 * m3 ) / r2a**3 ) * -( y3 + y2 )
    Fx1b = ( ( G * m1 * m3 ) / r1b**3 ) * -( x4 - x1 )
    Fy1b = ( ( G * m1 * m3 ) / r1b**3 ) * -( y4 + y1 )
    Fx2b = ( ( G * m2 * m3 ) / r2b**3 ) * -( x4 - x2 )
    Fy2b = ( ( G * m2 * m3 ) / r2b**3 ) * -( y4 + y2 )
    ax1 = ( Fx1a + Fx2a ) / m3
    ay1 = ( Fy1a + Fy2a ) / m3
    ax2 = ( Fx1b + Fx2b ) / m3
    ay2 = ( Fy1b + Fy2b ) / m3
    dxa = vx1 * dt
    dya = vy1 * dt
    dxb = vx2 * dt
    dyb = vy2 * dt
    dvxa = ax1 * dt
    dvya = ay1 * dt
    dvxb = ax2 * dt
    dvyb = ay2 * dt
    x3 = x3 + dxa
    y3 = y3 + dya
    x4 = x4 + dxb
    y4 = y4 + dyb
    vx1 = vx1 + dvxa
    vy1 = vy1 + dvya
    vx2 = vx2 + dvxb
    vy2 = vy2 + dvyb
    t = t + .01
    Point( x3 , y3 ).draw(win)
    Point( x4 , y4 ).draw(win)

win.getMouse()
win.close()
