from graphics import *

#This sets up the basic graph

win = GraphWin("Newton Method Graph", 600 , 600)
win.setCoords(-1 , -1 , 1 , 1)

#Below are the points to insert to make the basin plot

for numx in range(0 , 600 , 1 ):
    for numy in range(0 , 600, 1 ):
        x = -1 + ( numx / 599.0 ) * 2
        y = -1 + ( numy / 599.0 ) * 2
        m = x
        n = y
        A = x**3 - 3 * x * y**2 - 1
        B = 3 * x**2 * y - y**3
        C = 3 * x**2 - 3 * y**2
        D = 6 * x * y
        t=0
        while t <= 100 :
            p = x - ( A * C + B * D ) / ( C**2 + D**2 )
            q = y - ( B * C - A * D ) / ( C**2 + D**2 )
            x = p
            y = q
            A = x**3 - 3 * x * y**2 - 1
            B = 3 * x**2 * y - y**3
            C = 3 * x**2 - 3 * y**2
            D = 6 * x * y
            t = t + 1

        if .9 < x < 1.1 :
            z = Point( m , n )
            z.setFill(color_rgb( 51 , 0 , 102 ))
            z.draw(win)
        elif y < 0 :
            z = Point( m , n )
            z.setFill(color_rgb( 102 , 51 , 153 ))
            z.draw(win)
        else :
            z = Point( m , n )
            z.setFill(color_rgb( 204 , 153 , 255 ))
            z.draw(win)
            
win.getMouse()
win.close()
