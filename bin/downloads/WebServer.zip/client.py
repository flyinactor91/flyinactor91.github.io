#!/usr/bin/python

##--Michael duPont
##--CSC 250 Networking Languages
##--TCP client to mimic browser request for file from tcpServer.py and print recieved data

##--The tick-recv structure implemented below is overly simple and does not take connection speed or timeouts into considderation
##--I found that the index.html file from turing took anywhere between 12 and 15 ticks to transmit, so 100 should be adequate just as a PoC
##--Example, 100 ticks was enough to transmit Socket1_WebServer.pdf

##--Note: Must be called with sudo on linux since port 80

from socket import *

def main():
	serverName = 'localhost' #Change to server locale
	serverPort = 80 #50000
	clientSocket = socket(AF_INET , SOCK_STREAM)
	
	requestedFile = raw_input("\nRequested File Name: ")
	clientSocket.connect((serverName, serverPort))
	clientSocket.send('GET /' + requestedFile)
	
	##--Recieve incoming file--##
	ticks = 0
	rec = ''
	while ticks < 100:
		ticks += 1
		try:
			rec += clientSocket.recv(1024)
		except:
			pass
	print rec

main()
