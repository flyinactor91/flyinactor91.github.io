#!/usr/bin/python

##--Michael duPont
##--CSC 250 Networking Languages
##--TCP server that sends files to browser and/or terminal clients

##--PRO: TCP server can use browser as client if port 80
##--PRO: Supports multi browser calls to load multiple-file content web pages (my index.html requests .css and .js to fully run)
##--PRO: Non-html,non-application files printed in browser as text
##--FUT: Only supports GET; POST would be implemented later
##--BUG: Corrupts complex file types (.pdf .zip) on destination save
##--BUG: When running on Windows through Python IDLE, requires KeyboardInterupt plus a new page request to exit, causing client-side error
##--     --Not an issue on Linux

##--Note: Must be called with sudo on Linux since port 80


#import socket module
from socket import *

def main():
	try:
		serverPort = 80
		serverSocket = socket(AF_INET , SOCK_STREAM)
		#Prepare a server socket
		serverSocket.bind(('' , serverPort))
		serverSocket.listen(1)
		print 'The server is ready to recieve\n\n'
	
		while True:
			#Establish the connection
			connectionSocket, addr = serverSocket.accept()
			try:
				message = connectionSocket.recv(1024)
				if message != '':
					print str(addr) + '\nMessage recieved: ' + message
					uRequest = message.split()[0]
					if uRequest == 'GET':
						filename = message.split()[1]
						f = open(filename[1:])
						outputdata = f.readlines()
						fileType = filename[filename.find('.')+1:]
						##--Note: Request to "#Send one HTTP header line into socket" caused problems when using browser as client and has been removed
						#Send the content of the requested file to the client
						for i in range(len(outputdata)):
							connectionSocket.send(outputdata[i])
					else:
						#Send responce message for bad request
						connectionSocket.send('400 Error: Bad Request')
				connectionSocket.close()
			except IOError:
				#Send responce message for file not found
				connectionSocket.send('404 Error: File not found')
				#Close client socket
				connectionSocket.close()
	except KeyboardInterrupt:
		print '\nShuting down'
		serverSocket.close()

main()
