//--This is the C++ version of the Vigenere Cypher--//
//--It is designed to take cmdln or file input--//
//--It depends on whether the exe is called with--//
//--2 or 3 different parameters--//

#include <iostream>
#include <fstream>
#include <string>
#include <stdio.h>
#include <stdlib.h>
using namespace std;

int main(int argc , const char *argv[]) {

  //--checks to see if all parameters are present and exits if not--//
  if (argc < 3 || argc > 4) {
    cout << "Usage: " << argv[0] << "   takes two or three parameters:\n\t'-e' or '-d'\n\tCypher KEY text\n\t.txt file input (optional)\n"  << endl;
    exit(1);
  }

  //--gets and initializes values from command line--//
  string opt = argv[1];
  string key = argv[2];
  string mess = "";
  string cyph = "";
  string line;

  //--encryption--//
  if (opt == "-e") {
    cout << endl << "Encryption" << endl;

    //--if file not given, read in message text from cmdln--//
    if (argc == 3) {
      while(mess == "") {
	getline(cin , line);
	mess += line;
      }
    }

    //--if file given, read in message text from file--//
    if (argc == 4) {
      string finName = argv[3];
      ifstream fin (finName.c_str());
      if (fin.is_open() != true) {
	cout << "No such file\n" << endl;
	exit(1);
      }
      while (fin.good()) {
	getline(fin , line);
	mess += line;
      }
      fin.close();
    }

    //--set message and key to UPPERCASE--//
    //--using 'unsigned int' doubles the length of the message/key that can be used--//
    for(unsigned int i = 0 ; i < mess.length() ; i++) {mess[i] = toupper(mess[i]);}
    for(unsigned int i = 0 ; i < key.length() ; i++) {key[i] = toupper(key[i]);}

    cout << "Message: " << mess << endl;
    
    //--repeat key to match or excede message length--//
    while (key.length() < mess.length()) {key = key + key;}

    //--uses ascii value for each char in message and key to encrypt new letter according to Vigenere's cypher--//
    cyph = "";
    for(unsigned int i = 0 ; i < mess.length() ; i++) {
      int mVal = (int) mess[i];
      if(mVal == 32) cyph = cyph + " ";
      else {
	int kVal = (int) key[i];
	char charSet = 65 + ((mVal + kVal) % 26);
	cyph += charSet;
      }
    }
    cout << "Cypher: " << cyph << endl << endl;
  }


    //--decrpytion--//
  else if (opt == "-d") {
    cout << endl << "Decrpytion" << endl;

    //--if file not given, read in cypher text from cmdln--//
    if (argc == 3) {
      while (cyph == "") {
	getline(cin , line);
	cyph += line;
      }
    }

    //--if file given, read in cypher text from file--//
    if (argc == 4) {
      string finName = argv[3];
      ifstream fin (finName.c_str());
      if (fin.is_open() != true) {
	cout << "No such file\n" << endl;
	exit(1);
      }
      while (fin.good()) {
	getline(fin , line);
	cyph += line;
      }
      fin.close();
    }

    //--set cypher and key to UPPERCASE--//
    //--using 'unsigned int' doubles the length of the message/key that can be used--//
    for(unsigned int i = 0 ; i < cyph.length() ; i++) {cyph[i] = toupper(cyph[i]);}
    for(unsigned int i = 0 ; i < key.length() ; i++) {key[i] = toupper(key[i]);}

    cout << "Cypher: " << cyph << endl;
    
    //--repeat key to match or excede cypher length--//
    while (key.length() < cyph.length()) {key = key + key;}

    //--uses ascii value for each char in cypher and key to decrypt new letter according to Vigenere's cypher--//
    mess = "";
    for(unsigned int i = 0 ; i < cyph.length() ; i++) {
      int cVal = (int) cyph[i];
      if (cVal == 32) mess += " ";
      else {
	int kVal = (int) key[i];
	int newVal = cVal - kVal;
	if (newVal < 0) newVal += 26;
	char charSet = 65 + (newVal % 26);
	mess += charSet;
      }
    }
    cout << "Message: " << mess << endl << endl;
  }
  return 0;
}
