Michael duPont
CSC 250 Networking Languages

These programs allow for a client to connect to a server a leave messages for another client to recieve.

In order to send the messages, the client must specify the name of the person it is being sent to and their IP address if it is the first time sending them a message. This architecture assumes that the name of the person is equivilent to the name of the computer that they are using (it specifically asks "What computer do you want to send the message to?"). The user name is included in the stored message. When a user connects and chooses to recieve any stored messages, the server returns only those messages listed for the connecting IP address regardless of the recieving clients user name. A client can view any stored name/IP address for reference when writing a new message. The user can also call for the server (which keeps a centralized dictionary of clients who have connected to it) to update the client's local storage. The user is prompted upon first run to enter a user name and is then saved locally. The user can change their name at any time and have their new name saved. Quit and help commands are also available.

Admin tools are also included since the server has no native input capability. All these tools require the client to enter a password which is sent to the server along with the rest of the information. The server checks that against its locally-set password. The admin can display all saved messages stored on the server. I didn't find it necessary to display the IP storage since the client can already update then show. However, the admin can delete the message storage and IP storage for a server reset. The admin can also remotely shutdown the server. This is preferable to breaking the program on-site since it can save whatever information is currently being stored for when it starts back up again. The server keeps a connection log that shows connected IP, port number, user name, and action taken. It also notes if a new IP connected and if the client-submitted password was correct.


Because of the way pickle files are written and loaded...
###### You must run "createDictPickle.py [-client / -server]" before first run.

You must also change "serverName" in client.py to be the IP address (or "localhost" if selfcontained) of the compter the server is running on.
