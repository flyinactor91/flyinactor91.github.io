#!/usr/bin/python

##--Michael duPont
##--CSC 250 Networking Languages
##--TCP server that saves messages and DNS-stlye IP look-up
##--Available commands to recieve:
##--	msg  : Add a message to the storage for a particular IP address
##--	rcv  : Send all messages associated with connected IP 
##--	updt : Update local IP addresses from server
##--Admin Tools (requires server password):
##--	AdminShowAll  : Return list of all messages stored on server
##--	AdminClear    : Clear all IP addresses and messages
##--	AdminShutdown : Save data and shutdown
##--Run "createDictPickle.py -server" before first run

import pickle
from socket import *

##--Takes a list or dictionary and returns a formatted string to send to client--##
def returnString(tableIn):
	stringOut = ""
	
	##--If given dictionary--##
	if type(tableIn) == type({}):
		for key in tableIn:
			stringOut += "\n\n" + key + "\t" + str(returnString(tableIn[key]))	#Recursive call to format list for given key
	
	##--If given list--##
	else:
		for entry in tableIn:
			stringOut += "\n\t" + entry
	return stringOut
##--End returnString--##

##--Main Server Function--##
def main():
	serverPort = 60145
	serverPassword = "letmein"	#Declares server Admin password
	quitFlag = False
	
	##--Load in (via pickle) IP dictionary and text storage dictionary--##
	storageFile = open('ServerStorage.pkl', 'rb')
	IPStorage = pickle.load(storageFile)
	textStorage = pickle.load(storageFile)
	storageFile.close()
	
	serverSocket = socket(AF_INET , SOCK_STREAM)
	serverSocket.bind(('' , serverPort))
	serverSocket.listen(1)
	print 'The server is ready to recieve'
	
	##--Main Loop--##
	while not quitFlag:
		
		##--Begin once the server recieves a connection--##
		connectionSocket , addr = serverSocket.accept()
		stringIn = connectionSocket.recv(1024)
		stringIn = stringIn.split("&&&")
		command = stringIn[0]
		print str(addr) , stringIn[1] , command
		
		##--If connected IP is not in database, add it with it's name--##
		if addr[0] not in textStorage:
			IPStorage[stringIn[1]] = addr[0]
			print "Added new IP"
		
		##--Add message to textStorage--##
		if command == "msg":
			sendTo = stringIn[2]
			textIn = stringIn[3]
			if sendTo not in textStorage:
				textStorage[sendTo] = []
			textStorage.get(sendTo).append(textIn)
			connectionSocket.send("Server has recieved your text")
		
		##--Return all messages addressed to the connected IP--##
		elif command == "rcv":
			if str(addr[0]) not in textStorage:
				connectionSocket.send("Your IP has not recieved any text")
			else:
				connectionSocket.send(returnString(textStorage[addr[0]]))
				del textStorage[addr[0]]
		
		##--Return stored IP addresses--##
		elif command == "updt":
			sendDict = pickle.dumps(IPStorage)
			connectionSocket.send(sendDict)
		
		##--Admin Tools--##
		##--Saves data and shuts down server--##
		elif command == "adminshutdown":
			password = stringIn[2]
			if password == serverPassword:
				print "\tTrue"
				storageFile = open('ServerStorage.pkl', 'wb')
				pickle.dump(IPStorage, storageFile)
				pickle.dump(textStorage, storageFile)
				storageFile.close()
				connectionSocket.send("Server has saved data and is now shutting down\n")
				quitFlag = True
			else:
				print "\tFalse"
				connectionSocket.send("Access Denied")
		
		##--Clears all server data--##
		elif command == "adminclear":
			password = stringIn[2]
			if password == serverPassword:
				print "\tTrue"
				IPStorage = {}
				textStorage = {}
				connectionSocket.send("Server has reset all storage")
			else:
				print "\tFalse"
				connectionSocket.send("Access Denied")
		
		##--Returns all data in textStorage--##
		elif command == "adminshowall":
			password = stringIn[2]
			if password == serverPassword:
				print "\tTrue"
				retString = "\nText Stored on Server:" + returnString(textStorage)
				connectionSocket.send(retString)
			else:
				print "\tFalse"
				connectionSocket.send("Access Denied")
				
		##--Exception acts as a safeguard in case something went wrong during transmition--##
		else:
			print "Command error"
			connectionSocket.send("Server did not recognise the command given")
		connectionSocket.close()

	##--End Main Loop--##
##--End main--##

main()
