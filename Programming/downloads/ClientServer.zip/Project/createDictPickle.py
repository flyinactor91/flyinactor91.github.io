#!/usr/bin/python

##--Michael duPont
##--CSC 250 Networking Languages
##--Setup program to create pickled dictionaries for TCP-DNS project
##--Must call with "-client" or "-server"

import sys
import pickle

##--Create client IPStorage dictionary into "ClientStorage.pkl"--##
if sys.argv[1] == "-client":
	userName = ""
	IPStorage = {}
	output = open('ClientStorage.pkl' , 'wb')
	pickle.dump(userName , output)
	pickle.dump(IPStorage , output)
	
##--Create server IPStorage and  dictionary into "ClientStorage.pkl"--##
elif sys.argv[1] == "-server":
	IPStorage = {}
	textStorage = {}
	output = open('ServerStorage.pkl' , 'wb')
	pickle.dump(IPStorage , output)
	pickle.dump(textStorage , output)
	
output.close()
