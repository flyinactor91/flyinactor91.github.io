#!/usr/bin/python

##--Michael duPont
##--CSC 250 Networking Languages
##--TCP client that saves a local DNS-style look-up
##--Available commands:
##--	msg     : Send a message to a name/IP address
##--	rcv     : Revieve all messages from server for your IP address
##--	show    : Show all saved Names and IP addresses
##--	updt    : Update local IP addresses from server
##--	newuser : Change user name
##--	help    : Display inline help
##--	quit    : Exit program
##--Admin Tools (requires server password):
##--	AdminShowAll  : Show list of all messages stored on server
##--	AdminClear    : Clear all IP addresses and messages from server
##--	AdminShutdown : Save data and shutdown server remotely
##--Run "createDictPickle.py -client" before first run

from socket import *
import pickle

##--Main Client Function--##
def main():
	recipiant = ""
	message = ""
	command = ""
	quitFlag = False
	
	##--Load in (via pickle) IP dictionary--##
	storageFile = open('ClientStorage.pkl', 'rb')
	userName = pickle.load(storageFile)
	IPStorage = pickle.load(storageFile)
	storageFile.close()
	
	##--Setup socket--##
	serverName = "localhost" #"localhost" ######Change this to the IP address of whatever computer the server is running on
	serverPort = 60145
	
	##--Ask user for name and init--##
	if userName == "":
		userName = raw_input("What is your name? : ")
	else:
		print "\nWelcome back" , userName
	print "Type 'help' for a list of available commands"
		
	##--Command Loop--##
	while not quitFlag:
		command = raw_input("\ncmd: ")   #Ask user for command input
		command = command.lower()
		
		##--Send a message--##
		if command == "msg":
			recipiant = raw_input("What computer do you want to send the message to? ")	#Asks user who they want to send the message to
			
			##--Checks to see if the recipiant and their IP is already locally stored--##
			if recipiant not in IPStorage:
				IPval = raw_input("What is their IP address? : ")	#Asks user for the recipiants IP address
				IPStorage[recipiant] = IPval	#Adds recipiant name and IP address into local IP 
			message = userName + ": " + raw_input(">>> ")	#Ask user for message content. Formats -> "Name: Message"
			
			##--Connects to server, sends, and recieves data--##
			clientSocket = socket(AF_INET , SOCK_STREAM)
			clientSocket.connect((serverName, serverPort))
			clientSocket.send(command + "&&&" + userName + "&&&" + IPStorage[recipiant] + "&&&" + message)
			rec = clientSocket.recv(1024)
			print rec
			clientSocket.close()
			#quitFlag = True
			
		##--Recieve all messages addressed to this IP--##
		elif command == "rcv":
		
			##--Connects to server, sends, and recieves data--##
			clientSocket = socket(AF_INET , SOCK_STREAM)
			clientSocket.connect((serverName, serverPort))
			clientSocket.send(command + "&&&" + userName)
			rec = clientSocket.recv(1024)
			print rec
			clientSocket.close()
			#quitFlag = True
			
		##--Print list of names with corresponding IP address--##
		elif command == "show":
			for key in IPStorage:
				print key , IPStorage[key]
		
		##--Updates IP dictionary with values from server dictionary not found locally--##
		elif command == "updt":
		
			##--Connects to server, sends, and recieves data--##
			clientSocket = socket(AF_INET , SOCK_STREAM)
			clientSocket.connect((serverName, serverPort))
			clientSocket.send(command + "&&&" + userName)
			rec = clientSocket.recv(1024)
			
			##--Update local dictionary--##
			recDict = pickle.loads(rec)	#Unpickle recieved dictionary string
			for key in recDict:
			
				##--Update existing contacts--##
				if key in IPStorage:
					IPStorage[key] = recDict[key]
					
				##--Add new contacts--##
				if key not in IPStorage:
					IPStorage[key] = recDict[key]
			print "IP dictionary has been updated"
			clientSocket.close()
			#quitFlag = True
		
		##--Change userName--##
		elif command == "newuser":
			newUser = raw_input("What is your name? : ")
			if newUser == userName:
				print "You are already using that name"
			else:
				
				userName = newUser
				print "You are now known as" , userName
					
		##--Admin actions if password is correct:--##
			##--AdminShutdown shuts down server--##		
			##--AdminClear clears server storage--##		
			##--AdminShowAll shows all text stored on the server--##		
		elif command == "adminshutdown" or command == "adminclear" or command == "adminshowall":
			password = raw_input("Server Password: ")	#Ask for password to send to server
			
			##--Connects to server, sends, and recieves data--##
			clientSocket = socket(AF_INET , SOCK_STREAM)
			clientSocket.connect((serverName, serverPort))
			clientSocket.send(command + "&&&" + userName + "&&&" + password)
			rec = clientSocket.recv(1024)
			print rec
			clientSocket.close()
			if rec == "Server has saved data and is now shutting down":
				quitFlag = True
		
		##--Quit--##
		elif command == "quit":
			quitFlag = True
			
		##--Help--##
		elif command == "help":
			print "Available commands:\n\tMsg\tSend a message\n\tRcv\tCheck to see if your IP has recieved any messages\n\tShow\tShow a list of stored IP addresses\n\tUpdt\tUpdate stored IP addresses from server\n\tNewUser\tChange user name\n\tQuit\tQuit the program\n\tAdmin Tools:\n\t\tAdminShowAll\tShows all stored text on server\n\t\tAdminClear\tClear server storage\n\t\tAdminShutdown\tSends server into shutdown mode"
		
		##--Exception--##
		else:
			print "Not a recognised command"
		
		##--End Command Loop--##
		#clientSocket.close()
	
	##--Save IP dictionary--##
	storageFile = open('ClientStorage.pkl', 'wb')
	pickle.dump(userName , storageFile)
	pickle.dump(IPStorage , storageFile)
	storageFile.close()
	
	print "\nGoodbye\n"
##--End main--##

main()
